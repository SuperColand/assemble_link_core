# p4-core
version: 0.1

## 构建Docker镜像
```shell
python manage.py docker-build
```

## 导出Docker镜像
```shell
python manage.py docker-save
```

## 打包内核

```shell
python manage.py package
```

## 测试

```shell
python manage.py test
```
