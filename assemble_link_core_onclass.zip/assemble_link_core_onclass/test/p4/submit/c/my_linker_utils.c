/*****************************************************************
 * BUAA Fall 2022 Fundamentals of Computer Hardware
 * Project4 Assembler and Linker
 *****************************************************************
 * my_linker_utils.c
 * Linker Submission
 *****************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "lib/tables.h"
#include "linker-src/linker_utils.h"

int isok(uint32_t inst){
    uint32_t i = inst << 26;
    if(i == 2)
        return 1;
    if(i == 3)
        return 2;
    if(i == 15)
        return 3;
    if(i == 13)
        return 4;
    return 0;
}
int32_t relocate_inst(uint32_t inst, uint32_t offset, SymbolTable *symtbl, SymbolTable *reltbl){

    int op = isok(inst);
    if(op == 1 || op == 2){ //j
        int64_t a = get_addr_for_symbol(symtbl, get_symbol_for_addr(reltbl, offset));
        return ((inst >> 26) << 26) | (((1 << 26) - 1) & a);
    }else if(op == 3 || op == 4){
        const char *sym = get_symbol_for_addr(reltbl, offset);
        char *t = strtok(sym, "@");
        char *tt = strtok(NULL, LINKER_IGNORE_CHARS);
        int p = 0;
        if(strcmp(tt, "Hi") == 0)
            p = 1;
        if(strcmp(tt, "Lo") == 0)
            p = 2;
        int64_t a = get_addr_for_symbol(symtbl, t);
        if(p == 2){
            a += 4;
        }
        return ((inst >> 16) << 16) | (((1 << 16) - 1) & a);
    }else{
        return inst;
    }

}

/*
 * Detect whether the given instruction needs relocation.
 *
 * Return value:
 *  1 if the instruction needs relocation, 0 otherwise.
 *
 * Arguments:
 *  reltbl: the relocation table.
 *  offset: the address of an instruction in the file.
 * 
 * Hint:
 *  Use get_symbol_for_addr().
 */
int inst_needs_relocation(SymbolTable *reltbl, uint32_t offset) {

    if(get_symbol_for_addr(reltbl, offset) == NULL)
        return 0;
    return 1;

}

/*
 * Builds the symbol table and relocation data for a single file.
 * Read the .data, .text, .symbol, .relocation segments in that order.
 * The size of the .data and .text segments are read and saved in the
 * relocation table of the current file. For the .symbol and .relocation
 * segments, save the symbols in them in the corresponding locations.
 *
 * Return value:
 * 0 if no errors, -1 if error.
 *
 * Arguments:
 * input:            file pointer.
 * symtbl:           symbol table.
 * reldt:            pointer to a Relocdata struct.
 * base_text_offset: base text offset.
 * base_data_offset: base data offset.
 * 
 * Hint:
 *  Use calc_text_size(), calc_data_size(), add_to_symbol_table();
 */
int fill_data(FILE *input, SymbolTable *symtbl, RelocData *reldt, uint32_t base_text_offset, uint32_t base_data_offset) {

    int re = 0;
    char line[LINKER_BUF_SIZE];
    while(fgets(line, LINKER_BUF_SIZE, input)){
        char *set = strtok(line, LINKER_IGNORE_CHARS);
        if(strcmp(set, ".data") == 0){
            reldt->data_size = calc_data_size(input);
        }else if(strcmp(set, ".text") == 0){
            reldt->text_size = calc_text_size(input);
        }else if(strcmp(set, ".symbol") == 0){
            if(add_to_symbol_table(input, symtbl, base_text_offset, base_data_offset) == -1)
                re = -1;
        }else if(strcmp(set, ".relocation") == 0){
            if(add_to_symbol_table(input, reldt->table, 0, 0) == -1)
                re = -1;
        }
    }

    return re;

}