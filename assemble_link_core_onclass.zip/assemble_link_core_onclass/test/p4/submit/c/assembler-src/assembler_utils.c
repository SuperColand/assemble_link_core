/*****************************************************************
 * BUAA Fall 2021 Fundamentals of Computer Hardware
 * Project7 Assembler and Linker
 *****************************************************************
 * assembler_utils.c
 * Utilities for assembler
 *****************************************************************/

#include <stdio.h>
#include <string.h>

#include "../lib/tables.h"
#include "../lib/translate_utils.h"
#include "assembler_utils.h"

const char *ASSEMBLER_IGNORE_CHARS = " \f\n\r\t\v,()";
const int MAX_ARGS = 3;
const int ASSEMBLER_BUF_SIZE = 1024;

 void raise_label_error(uint32_t input_line, const char *label) {
    printf("Error - invalid label at line %d: %s\n", input_line, label);
}

/* Call this function if more than MAX_ARGS arguments are found while parsing
 * arguments.
 *
 * INPUT_LINE is which line of the input file that the error occurred in. Note
 * that the first line is line 1 and that empty lines are included in the count.
 *
 * EXTRA_ARG should contain the first extra argument encountered.
 */
 void raise_extra_arg_error(uint32_t input_line, const char *extra_arg) {
    printf("Error - extra argument at line %d: %s\n", input_line, extra_arg);
}

/* You should call this function if write_pass_one() or translate_inst()
 * returns -1.
 *
 * INPUT_LINE is which line of the input file that the error occurred in. Note
 * that the first line is line 1 and that empty lines are included in the count.
 */
void raise_inst_error(uint32_t input_line, const char *name, char **args, int num_args) {

    printf("Error - invalid instruction at line %d: %s\n", input_line, name);
}

/*  A helpful helper function that parses instruction arguments. It raises an error
 *  if too many arguments have been passed into the instruction.
 */
int parse_args(uint32_t input_line, char **args, int *num_args) {
    char *token;
    while ((token = strtok(NULL, ASSEMBLER_IGNORE_CHARS))) {
        if (*num_args < MAX_ARGS) {
            args[*num_args] = token;
            (*num_args)++;
        } else {
            raise_extra_arg_error(input_line, token);
            return -1;
        }
    }
    return 0;
}

/* Truncates the string at the first occurrence of the '#' character. */
 void skip_comment(char *str) {
    char *comment_start = strchr(str, '#');
    if (comment_start) {
        *comment_start = '\0';
    }
}

